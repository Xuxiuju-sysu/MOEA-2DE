clc;
clear;
close all;

% Problem Definition
Gen=200;          % Maximum Number of Iterations
pop=20;           % Population Size
pm=0.1;           % probability of mutation
pc=0.9;           % probability of crossover
M=2;              % objective number
CR=0.3;F=0.3;     % DE parameter
  
run = 1;         % running times
load peak1;
load peak2;
load Rugged1;
load Rugged2;
for j = 1 : 4
    if j == 1
        model = peak1;
        problemIndex = 1;
    elseif j == 2
        model = peak2;
        problemIndex = 1;
    elseif j == 3
        model = Rugged1;
        problemIndex = 2;
    else
        model = Rugged2;
        problemIndex = 2;
    end
    nVar=model.n;       % Number of Decision Variables = searching dimension = number of path node
    for i = 1 : run
        [score_MOEA_2DE{j,i},population_MOEA_2DE{j,i}] = MOEA_2DE(M,model,pop,Gen,F,pc,pm,nVar,problemIndex);
    end
end
