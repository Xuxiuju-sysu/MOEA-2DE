function [Score] = calMetirc(MetricIndex,PopObj,problemIndex)

if MetricIndex == 1
    if problemIndex == 1
        a = [4000,4000];
    else
        a = [50,10];
    end
    Score = HV(PopObj,a);
else
    Score = PD(PopObj);
end

end

